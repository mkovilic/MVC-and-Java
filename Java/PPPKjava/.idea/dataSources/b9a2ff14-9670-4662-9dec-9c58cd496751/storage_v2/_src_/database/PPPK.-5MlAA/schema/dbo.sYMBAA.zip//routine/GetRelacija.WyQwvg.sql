CREATE PROCEDURE [dbo].[GetRelacija]
	@IDRelacija int
AS
SELECT * FROM Relacija WHERE Relacija.IDRelacija = @IDRelacija
go

