
CREATE PROCEDURE [dbo].[DeleteDrzava]
	@IDDrzava int
AS
DELETE FROM Relacija WHERE Relacija.GradDolazakID IN(SELECT Grad.IDGrad FROM Grad WHERE Grad.DrzavaID=@IDDrzava )
DELETE FROM Relacija WHERE Relacija.GradPolazakID IN(SELECT Grad.IDGrad FROM Grad WHERE Grad.DrzavaID=@IDDrzava )
DELETE FROM Grad WHERE Grad.DrzavaID = @IDDrzava
DELETE FROM Drzava WHERE Drzava.IDDrzava = @IDDrzava

go

