CREATE PROCEDURE [dbo].[GetKategorijaServis]
	@IDKategorijaServis int
AS
SELECT * FROM KategorijaServis WHERE KategorijaServis.IDKategorijaServis = @IDKategorijaServis
go

