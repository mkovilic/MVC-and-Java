CREATE PROCEDURE [dbo].[AddKategorijaServis]
	@IDKategorijaServis int,
	@Naziv nvarchar(30)
AS
BEGIN
	IF @IDKategorijaServis IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.KategorijaServis ON
		INSERT INTO KategorijaServis(IDKategorijaServis, Naziv) VALUES(@IDKategorijaServis, @Naziv)
		SET IDENTITY_INSERT dbo.KategorijaServis OFF
		END
	ELSE
		BEGIN
		INSERT INTO KategorijaServis VALUES(@Naziv)
		END
END
go

