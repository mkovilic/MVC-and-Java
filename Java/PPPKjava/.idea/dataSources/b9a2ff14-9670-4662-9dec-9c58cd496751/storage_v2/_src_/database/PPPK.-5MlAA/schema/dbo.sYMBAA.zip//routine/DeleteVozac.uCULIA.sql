CREATE PROCEDURE [dbo].[DeleteVozac]
	@IDVozac int
AS
DELETE FROM Relacija WHERE PutniNalogID  IN (SELECT p.IDPutniNalog FROM PutniNalog as p WHERE p.VozacID = @IDVozac)
DELETE FROM PutniNalog WHERE VozacID = @IDVozac
DELETE FROM Vozac WHERE Vozac.IDVozac = @IDVozac
go

