CREATE PROCEDURE [dbo].[GetKategorijaTroska]
	@IDKategorijaTrosak int
AS
SELECT * FROM KategorijaTrosak WHERE KategorijaTrosak.IDKategorijaTrosak = @IDKategorijaTrosak
go

