CREATE PROCEDURE [dbo].[DeletePutniNalog]
	@IDPutniNalog int
AS
UPDATE PutniNalog SET VozacID=NULL,VoziloID=NULL WHERE IDPutniNalog = @IDPutniNalog 
UPDATE Relacija SET PutniNalogID=NULL WHERE PutniNalogID = @IDPutniNalog
DELETE FROM PutniNalog WHERE IDPutniNalog = @IDPutniNalog
go

