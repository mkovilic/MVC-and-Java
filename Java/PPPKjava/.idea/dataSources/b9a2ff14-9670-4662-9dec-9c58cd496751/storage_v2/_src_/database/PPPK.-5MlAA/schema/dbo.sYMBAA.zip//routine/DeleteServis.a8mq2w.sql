CREATE PROCEDURE [dbo].[DeleteServis]
	@IDServis int
AS
DELETE FROM Servis WHERE Servis.IDServis = @IDServis
go

