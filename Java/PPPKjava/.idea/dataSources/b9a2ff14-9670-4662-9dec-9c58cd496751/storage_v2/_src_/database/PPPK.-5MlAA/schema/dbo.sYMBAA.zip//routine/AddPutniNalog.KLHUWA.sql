CREATE PROCEDURE [dbo].[AddPutniNalog]
	@IDPutniNalog int,
	@VozacID int,
	@DatumOdlaska datetime,
	@DatumDolaska datetime,
	@BrojSati int,
	@BrojDnevnica int,
	@IznosDnevnice int,
	@Opis nvarchar(100),
	@VoziloID int
AS
BEGIN
	IF @IDPutniNalog IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.PutniNalog ON
		INSERT INTO PutniNalog(IDPutniNalog, VozacID, DatumOdlaska, DatumDolaska, BrojSati, BrojDnevnica, IznosDnevnice, Opis, VoziloID) VALUES (@IDPutniNalog, @VozacID, @DatumOdlaska, @DatumDolaska, @BrojSati, @BrojDnevnica, @IznosDnevnice, @Opis, @VoziloID)
		SET IDENTITY_INSERT dbo.PutniNalog OFF
		END
	ELSE
		BEGIN
		INSERT INTO PutniNalog VALUES(@VozacID, @DatumOdlaska, @DatumDolaska, @BrojSati, @BrojDnevnica, @IznosDnevnice, @Opis, @VoziloID)
		END
END
go

