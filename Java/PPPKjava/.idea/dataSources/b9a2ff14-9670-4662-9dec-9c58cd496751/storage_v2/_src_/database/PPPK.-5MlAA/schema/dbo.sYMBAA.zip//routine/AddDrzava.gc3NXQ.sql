CREATE PROCEDURE [dbo].[AddDrzava]
	@IDDrzava int,
	@Naziv nvarchar(30)
AS
	IF @IDDrzava IS NOT NULL
	BEGIN
		SET IDENTITY_INSERT dbo.Drzava ON
		INSERT INTO dbo.Drzava(IDDrzava,Naziv) VALUES(@IDDrzava,@Naziv)
		SET IDENTITY_INSERT dbo.Drzava OFF
	END
	ELSE
	BEGIN
		INSERT INTO dbo.Drzava(Naziv) VALUES(@Naziv)
	END

go

