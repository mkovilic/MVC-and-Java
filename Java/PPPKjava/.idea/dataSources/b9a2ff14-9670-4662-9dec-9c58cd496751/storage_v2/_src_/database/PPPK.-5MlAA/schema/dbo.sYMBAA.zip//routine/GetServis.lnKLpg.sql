CREATE PROCEDURE [dbo].[GetServis]
	@IDServis int
AS
SELECT * FROM Servis WHERE Servis.IDServis = @IDServis
go

