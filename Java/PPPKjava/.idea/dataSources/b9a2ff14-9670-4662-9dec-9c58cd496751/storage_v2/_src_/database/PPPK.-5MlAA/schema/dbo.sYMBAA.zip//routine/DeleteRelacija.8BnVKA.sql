CREATE PROCEDURE [dbo].[DeleteRelacija]
	@IDRelacija int
AS
DELETE FROM Relacija WHERE Relacija.IDRelacija = @IDRelacija
go

