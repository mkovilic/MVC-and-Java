CREATE PROCEDURE [dbo].[GetPutniNalog]
	@IDPutniNalog int
AS
SELECT * FROM PutniNalog WHERE PutniNalog.IDPutniNalog = @IDPutniNalog
go

