CREATE PROCEDURE [dbo].[GetVozaci]
AS
SELECT * FROM Vozac
go

