CREATE PROCEDURE [dbo].[GetVozilo]
	@IDVozilo int
AS
SELECT * FROM Vozilo WHERE Vozilo.IDVozilo = @IDVozilo
go

