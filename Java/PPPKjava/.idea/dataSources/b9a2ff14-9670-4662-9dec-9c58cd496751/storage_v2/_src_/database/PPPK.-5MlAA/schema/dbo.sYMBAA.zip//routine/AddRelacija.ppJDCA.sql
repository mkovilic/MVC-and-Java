
CREATE PROCEDURE [dbo].[AddRelacija]
	@IDRelacija int,
	@GradPolazakID int,
	@GradDolazakID int,
	@PutniNalogID int,
	@Kilometraza int,
	@PrijevozIznos int
AS
BEGIN
	IF @IDRelacija IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.Relacija ON
		INSERT INTO Relacija(IDRelacija, GradPolazakID, GradDolazakID, PutniNalogID, Kilometraza, PrijevozIznos) VALUES(@IDRelacija,@GradPolazakID,@GradDolazakID,@PutniNalogID,@Kilometraza,@PrijevozIznos)
		SET IDENTITY_INSERT dbo.Relacija OFF
		END
	ELSE
		BEGIN
		INSERT INTO Relacija VALUES(@GradPolazakID,@GradDolazakID,@PutniNalogID,@Kilometraza,@PrijevozIznos)
		END
END
go

