CREATE PROCEDURE [dbo].[GetRelacije]
AS
SELECT * FROM Relacija
go

