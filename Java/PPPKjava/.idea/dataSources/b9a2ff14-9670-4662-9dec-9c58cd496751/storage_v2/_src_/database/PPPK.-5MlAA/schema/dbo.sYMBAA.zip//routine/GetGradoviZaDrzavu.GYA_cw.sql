CREATE PROCEDURE [dbo].[GetGradoviZaDrzavu]
	@IDDrzava int
AS
SELECT * FROM Grad WHERE Grad.DrzavaID = @IDDrzava
go

