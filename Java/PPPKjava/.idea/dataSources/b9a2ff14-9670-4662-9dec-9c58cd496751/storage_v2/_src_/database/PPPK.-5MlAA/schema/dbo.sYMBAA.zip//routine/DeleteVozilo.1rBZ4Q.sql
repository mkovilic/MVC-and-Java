CREATE PROCEDURE [dbo].[DeleteVozilo]
	@IDVozilo int
AS
--DELETE FROM Relacija WHERE Relacija.PutniNalogID IN (SELECT PutniNalog.IDPutniNalog FROM PutniNalog WHERE PutniNalog.VoziloID = @IDVozilo)
UPDATE PutniNalog SET PutniNalog.VoziloID = NULL WHERE PutniNalog.VoziloID = @IDVozilo
UPDATE Servis SET Servis.VoziloID = NULL WHERE Servis.VoziloID = @IDVozilo
DELETE FROM Vozilo WHERE Vozilo.IDVozilo = @IDVozilo
go

