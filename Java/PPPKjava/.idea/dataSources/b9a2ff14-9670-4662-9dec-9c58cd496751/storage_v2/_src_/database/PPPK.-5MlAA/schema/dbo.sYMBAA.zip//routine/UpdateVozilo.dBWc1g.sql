CREATE PROCEDURE [dbo].[UpdateVozilo]
	@IDVozilo int,
	@Tip nvarchar(30),
	@Marka nvarchar(30),
	@GodinaProizvodnje int,
	@StanjeKilometra int
AS
UPDATE Vozilo SET Tip=@Tip, Marka=@Marka, GodinaProizvodnje=@GodinaProizvodnje,StanjeKilometra=@StanjeKilometra WHERE Vozilo.IDVozilo = @IDVozilo
go

