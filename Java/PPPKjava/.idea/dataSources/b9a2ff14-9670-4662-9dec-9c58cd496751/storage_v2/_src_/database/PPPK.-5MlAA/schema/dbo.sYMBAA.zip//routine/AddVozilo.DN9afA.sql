CREATE PROCEDURE [dbo].[AddVozilo]
	@IDVozilo int,
	@Tip nvarchar(30),
	@Marka nvarchar(30),
	@GodinaProizvodnje int,
	@StanjeKilometra int
AS
BEGIN
	IF @IDVozilo IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.Vozilo ON
		INSERT INTO Vozilo(IDVozilo, Tip, Marka, GodinaProizvodnje, StanjeKilometra) VALUES (@IDVozilo, @Tip, @Marka, @GodinaProizvodnje, @StanjeKilometra)
		SET IDENTITY_INSERT dbo.Vozilo OFF
		END
	ELSE
		BEGIN
		INSERT INTO Vozilo VALUES(@Tip,@Marka,@GodinaProizvodnje,@StanjeKilometra)
		END
END
go

