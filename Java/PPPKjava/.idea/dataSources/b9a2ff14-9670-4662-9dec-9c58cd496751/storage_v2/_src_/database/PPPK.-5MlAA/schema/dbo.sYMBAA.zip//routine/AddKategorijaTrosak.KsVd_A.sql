CREATE PROCEDURE [dbo].[AddKategorijaTrosak]
	@IDKategorijaTrosak int,
	@Naziv nvarchar(30)
AS
BEGIN
	IF @IDKategorijaTrosak IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.KategorijaTrosak ON
		INSERT INTO KategorijaTrosak(IDKategorijaTrosak, Naziv) VALUES(@IDKategorijaTrosak, @Naziv)
		SET IDENTITY_INSERT dbo.KategorijaTrosak OFF
		END
	ELSE
		BEGIN
		INSERT INTO KategorijaTrosak VALUES(@Naziv)
		END
END
go

