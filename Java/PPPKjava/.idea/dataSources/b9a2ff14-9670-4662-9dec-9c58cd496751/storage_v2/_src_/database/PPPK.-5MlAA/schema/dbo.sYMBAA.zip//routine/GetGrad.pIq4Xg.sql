CREATE PROCEDURE [dbo].[GetGrad]
	@IDGrad int
AS
SELECT * FROM Grad WHERE Grad.IDGrad = @IDGrad
go

