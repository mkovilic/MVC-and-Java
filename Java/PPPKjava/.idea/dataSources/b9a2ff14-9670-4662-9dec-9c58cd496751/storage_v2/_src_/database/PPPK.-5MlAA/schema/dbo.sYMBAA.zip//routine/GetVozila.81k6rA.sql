CREATE PROCEDURE [dbo].[GetVozila]
AS
SELECT * FROM Vozilo
go

