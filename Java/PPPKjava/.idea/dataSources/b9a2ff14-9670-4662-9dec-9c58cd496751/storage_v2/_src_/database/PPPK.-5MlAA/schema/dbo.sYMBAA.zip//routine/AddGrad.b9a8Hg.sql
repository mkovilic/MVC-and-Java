
CREATE PROCEDURE [dbo].[AddGrad]
	@IDGrad int,
	@DrzavaID int,
	@Naziv nvarchar(30)
AS
IF @IDGrad IS NOT NULL
BEGIN
SET IDENTITY_INSERT dbo.Grad ON
INSERT INTO Grad(IDGrad, DrzavaID, Naziv) VALUES(@IDGrad,@DrzavaID,@Naziv)
SET IDENTITY_INSERT dbo.Grad OFF
END
ELSE
BEGIN
INSERT INTO Grad(DrzavaID, Naziv) VALUES(@DrzavaID,@Naziv)
END

go

