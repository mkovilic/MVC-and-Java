
CREATE PROCEDURE [dbo].[GetKategorijeServisa]
AS
SELECT * FROM KategorijaServis
go

