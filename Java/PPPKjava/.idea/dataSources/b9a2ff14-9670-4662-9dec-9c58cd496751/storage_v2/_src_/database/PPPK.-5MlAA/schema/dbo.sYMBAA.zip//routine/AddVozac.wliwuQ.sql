CREATE PROCEDURE [dbo].[AddVozac]
	@IDVozac int,
	@FirstName nvarchar(30),
	@LastName nvarchar(30),
	@Mobitel nvarchar(15),
	@VozackaDozvola nvarchar(15)
AS
BEGIN
	IF @IDVozac IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.Vozac ON
		INSERT INTO Vozac(IDVozac, FirstName, LastName, Mobitel, VozackaDozvola) VALUES (@IDVozac, @FirstName, @LastName, @Mobitel, @VozackaDozvola)
		SET IDENTITY_INSERT dbo.Vozac OFF
		END
	ELSE
		BEGIN
		INSERT INTO Vozac(FirstName, LastName, Mobitel, VozackaDozvola) VALUES (@FirstName, @LastName, @Mobitel, @VozackaDozvola)
		END

END
go

