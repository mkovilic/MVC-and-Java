CREATE PROCEDURE [dbo].[AddServis]
	@IDServis int,
	@VoziloID int,
	@Cijena float,
	@Opis nvarchar(200),
	@Datum datetime,
	@KategorijaServisID int
AS
BEGIN
	IF @IDServis IS NOT NULL
		BEGIN
		SET IDENTITY_INSERT dbo.Servis ON
		INSERT INTO Servis(IDServis, VoziloID, Cijena, Opis, Datum, KategorijaServisID) VALUES (@IDServis, @VoziloID, @Cijena, @Opis, @Datum, @KategorijaServisID)
		SET IDENTITY_INSERT dbo.Servis OFF
		END
	ELSE
		BEGIN
		INSERT INTO Servis VALUES (@VoziloID, @Cijena, @Opis, @Datum, @KategorijaServisID)
		END
END
go

