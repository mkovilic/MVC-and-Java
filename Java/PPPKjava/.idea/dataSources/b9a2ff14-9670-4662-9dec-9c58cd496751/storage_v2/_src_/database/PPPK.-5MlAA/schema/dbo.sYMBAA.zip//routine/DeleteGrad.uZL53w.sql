CREATE PROCEDURE [dbo].[DeleteGrad]
	@IDGrad int
AS
DELETE FROM Relacija WHERE Relacija.GradDolazakID = @IDGrad
DELETE FROM Relacija WHERE Relacija.GradPolazakID = @IDGrad
DELETE FROM Grad WHERE Grad.IDGrad = @IDGrad
go

