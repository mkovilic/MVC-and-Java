CREATE PROCEDURE [dbo].[UpdatePutniNalog]
	@IDPutniNalog int,
	@VozacID int,
	@DatumOdlaska datetime,
	@DatumDolaska datetime,
	@BrojSati int,
	@BrojDnevnica int,
	@IznosDnevnice int,
	@Opis nvarchar(100),
	@VoziloID int
AS
BEGIN
UPDATE PutniNalog SET 
VozacID=@VozacID, 
DatumOdlaska=@DatumOdlaska, 
DatumDolaska=@DatumDolaska, 
BrojSati=@BrojSati, 
BrojDnevnica=@BrojDnevnica, 
IznosDnevnice=@IznosDnevnice,
Opis=@Opis, 
VoziloID=@VoziloID 
WHERE PutniNalog.IDPutniNalog = @IDPutniNalog
END
go

