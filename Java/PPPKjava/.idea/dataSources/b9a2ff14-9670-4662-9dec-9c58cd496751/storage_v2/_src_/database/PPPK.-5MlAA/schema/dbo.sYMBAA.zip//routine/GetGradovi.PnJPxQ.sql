CREATE PROCEDURE [dbo].[GetGradovi]
AS
SELECT * FROM Grad
go

