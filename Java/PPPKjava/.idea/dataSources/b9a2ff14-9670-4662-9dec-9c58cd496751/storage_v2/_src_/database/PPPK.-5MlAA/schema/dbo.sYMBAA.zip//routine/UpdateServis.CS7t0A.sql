CREATE PROCEDURE [dbo].[UpdateServis]
	@IDServis int,
	@VoziloID int,
	@Cijena float,
	@Opis nvarchar(200),
	@Datum datetime,
	@KategorijaServisID int
AS
BEGIN
UPDATE Servis SET 
VoziloID=@VoziloID, 
Cijena=@Cijena, 
Opis=@Opis, 
Datum=@Datum, 
KategorijaServisID=@KategorijaServisID
WHERE Servis.IDServis = @IDServis
END
go

