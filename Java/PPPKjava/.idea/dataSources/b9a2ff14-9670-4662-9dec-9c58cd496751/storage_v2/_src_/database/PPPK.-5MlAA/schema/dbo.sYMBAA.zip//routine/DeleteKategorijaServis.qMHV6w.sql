CREATE PROCEDURE [dbo].[DeleteKategorijaServis]
	@IDKategorijaServis int
AS
BEGIN
DELETE FROM Servis WHERE Servis.KategorijaServisID = @IDKategorijaServis
DELETE FROM KategorijaServis WHERE KategorijaServis.IDKategorijaServis = @IDKategorijaServis
END
go

