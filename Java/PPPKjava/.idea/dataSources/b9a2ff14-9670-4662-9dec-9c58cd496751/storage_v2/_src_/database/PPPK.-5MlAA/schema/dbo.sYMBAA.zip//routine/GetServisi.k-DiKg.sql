CREATE PROCEDURE [dbo].[GetServisi]
AS
SELECT * FROM Servis
go

