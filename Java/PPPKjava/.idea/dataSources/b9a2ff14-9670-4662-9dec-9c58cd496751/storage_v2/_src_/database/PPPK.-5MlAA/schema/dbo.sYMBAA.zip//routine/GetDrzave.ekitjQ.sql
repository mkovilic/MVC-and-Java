CREATE PROCEDURE [dbo].[GetDrzave]
AS
SELECT * FROM Drzava
go

