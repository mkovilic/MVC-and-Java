CREATE PROCEDURE [dbo].[GetVozac]
	@IDVozac int
AS
SELECT * FROM Vozac WHERE Vozac.IDVozac = @IDVozac
go

