CREATE PROCEDURE [dbo].[GetPutniNalozi]
AS
SELECT * FROM PutniNalog
go

