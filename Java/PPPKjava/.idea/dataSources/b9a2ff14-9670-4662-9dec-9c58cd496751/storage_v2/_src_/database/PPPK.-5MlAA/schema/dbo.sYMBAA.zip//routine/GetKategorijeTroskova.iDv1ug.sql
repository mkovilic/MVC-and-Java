CREATE PROCEDURE [dbo].[GetKategorijeTroskova]
AS
SELECT * FROM KategorijaTrosak
go

