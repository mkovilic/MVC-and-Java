CREATE PROCEDURE [dbo].[UpdateVozac]
	@IDVozac int,
	@FirstName nvarchar(30),
	@LastName nvarchar(30),
	@Mobitel nvarchar(15),
	@VozackaDozvola nvarchar(15)
AS
UPDATE Vozac SET FirstName=@FirstName, LastName=@LastName, Mobitel=@Mobitel, VozackaDozvola=@VozackaDozvola WHERE Vozac.IDVozac = @IDVozac
go

